﻿操作步骤：
	
1.打开虚拟机终端，进入到指定目录下	
2.输入./compile.sh,对源程序进行编译
	
3.输入./run.sh +选择条件，运行程序。传参时用'$@'进行传参。例如./run.sh  1 BUILDING 1995-03-29 1995-03-27 10 
4.若compile.sh或run.sh权限不够，输入chmod 777 compile.sh或chmod 777 run.sh提高权限，然后按操作步骤即可
